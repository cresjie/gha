'use strict';

Sortable.collections = ['attributes'];
